//
//  LoadingView.swift
//  wordApp1
//
//  Created by Serenay Güneş on 22.05.2024.
//

import SwiftUI

struct LoadingView: View {
    var body: some View {
        Text("Loading View Ekranı")
    }
}

#Preview {
    LoadingView()
}
