# 6 Sefer ile Kelime Ezberleme Sistemi

Bu proje, kullanıcıların belirli kelimeleri öğrenmelerini sağlayan bir mobil uygulamadır. Temel olarak, kullanıcılar belirli bir kelimeyi ezberlemek için altı seferlik bir sistem kullanır.

## Özellikler

- Kullanıcı Yetkilendirme ve Giriş Ekranı
- Kelime Ekleme Modülü
- Sınav Modülü
- Kullanıcı Ayarları
- Analiz Raporları

## Gereksinimler

- Xcode 12 veya üstü
- Swift 5
- SwiftUI
- Firebase veritabanı

## Kurulum
